import torch
from torchmetrics import Accuracy, ConfusionMatrix
from torchmetrics.regression import MeanSquaredError, MeanAbsoluteError

def accuracy(output, target):
    with torch.no_grad():
        pred = torch.argmax(output, dim=1)
        target = torch.argmax(target, dim=1)
        assert pred.shape[0] == len(target)
        correct = 0
        correct += torch.sum(pred == target).item()
    return correct / len(target)


def top_k_acc(output, target, k=3):
    with torch.no_grad():
        pred = torch.topk(output, k, dim=1)[1]
        assert pred.shape[0] == len(target)
        correct = 0
        for i in range(k):
            correct += torch.sum(pred[:, i] == target).item()
    return correct / len(target)

def acc(output, target):
    with torch.no_grad():
        accuracy = Accuracy(task="BINARY").to(torch.device("cuda", 0))
        accuracy.reset()
        return accuracy(output.float(), target.float())
    
def mse(output, target):
    with torch.no_grad():
        error = MeanSquaredError().to(torch.device("cuda", 0))
        error.reset()
        return error(output.float(), target.float())
    
def mae(output, target):
    with torch.no_grad():
        error = MeanAbsoluteError().to(torch.device("cuda", 0))
        error.reset()
        return error(output.float(), target.float())
    
def mae2(output, target):
    with torch.no_grad():
        abs = output.float() - target.float()
        sum_abs_error =  torch.sum(torch.absolute(abs)).item()
        return sum_abs_error
    
