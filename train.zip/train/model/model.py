import sys
import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision.models as models
from torchsummary import summary

sys.path.append("../")
from base import BaseModel


class MnistModel(BaseModel):
    def __init__(self, num_classes=10):
        super().__init__()
        self.conv1 = nn.Conv2d(1, 10, kernel_size=5)
        self.conv2 = nn.Conv2d(10, 20, kernel_size=5)
        self.conv2_drop = nn.Dropout2d()
        self.fc1 = nn.Linear(320, 50)
        self.fc2 = nn.Linear(50, num_classes)

    def forward(self, x):
        x = F.relu(F.max_pool2d(self.conv1(x), 2))
        x = F.relu(F.max_pool2d(self.conv2_drop(self.conv2(x)), 2))
        x = x.view(-1, 320)
        x = F.relu(self.fc1(x))
        x = F.dropout(x, training=self.training)
        x = self.fc2(x)
        return F.log_softmax(x, dim=1)

class multiTaskModel(BaseModel):
    def __init__(self, num_classes=2, mode=None):
        super().__init__()
        self.conv1 = nn.Conv2d(1, 8, kernel_size=(1, 4), padding='valid')
        self.conv2 = nn.Conv2d(8, 8, kernel_size=(1, 5), padding='same', stride=(1,1))
        self.conv3 = nn.Conv2d(8, 16, kernel_size=(1, 4), padding='valid')
        self.conv4 = nn.Conv2d(16, 16, kernel_size=(1, 4), padding='same', stride=(1,1))
        self.conv5 = nn.Conv2d(16, 32, kernel_size=(1, 4), padding='valid')
        self.conv6 = nn.Conv2d(32, 32, kernel_size=(1, 4), stride=(1,1))
        self.conv1_bn = nn.BatchNorm2d(8)
        self.conv2_bn = nn.BatchNorm2d(8)
        self.conv3_bn = nn.BatchNorm2d(16)
        self.conv4_bn = nn.BatchNorm2d(16)
        self.conv5_bn = nn.BatchNorm2d(32)
        self.conv6_bn = nn.BatchNorm2d(32)

        self.fc1_cls = nn.Linear(448, 32)
        self.fc2_cls = nn.Linear(32, num_classes)
        self.bn1_cls = nn.BatchNorm1d(448)
        self.bn2_cls = nn.BatchNorm1d(32)


        self.fc1_reg = nn.Linear(448, 32)
        self.fc2_reg = nn.Linear(32, num_classes)
        self.bn1_reg = nn.BatchNorm1d(448)
        self.bn2_reg = nn.BatchNorm1d(32)

        
             
    def backbone(self, x):
        x = F.relu(self.conv1_bn(self.conv1(x)))
        x = F.relu(self.conv2_bn(self.conv2(x)))
        x = F.max_pool2d(x, stride=(1,2),  kernel_size=(1,2))

        x = F.relu(self.conv3_bn(self.conv3(x)))
        x = F.relu(self.conv4_bn(self.conv4(x)))
        x = F.max_pool2d(x, stride=(1,2),  kernel_size=(1,2))

        
        x = F.relu(self.conv5_bn(self.conv5(x)))
        x = F.relu(self.conv6_bn(self.conv6(x)))
        x = F.max_pool2d(x, stride=(1,2),  kernel_size=(1,2))
        
        
        x = x.view(x.size(0), -1) # flatten

        return x
    
    def cls_head(self, x):
        x = self.bn1_cls(x)
        x = F.relu(self.fc1_cls(x))
        x = self.bn2_cls(x)
        x = F.dropout(x, training=self.training) 
        x = F.sigmoid(self.fc2_cls(x))
        return x
    
    def reg_head(self, x):
        x = self.bn1_reg(x)
        x = F.relu(self.fc1_reg(x))
        x = self.bn2_reg(x)
        x = F.dropout(x, training=self.training) 
        x = F.relu(self.fc2_reg(x))
        return x
    
    def forward(self, x):
        
        x_cls = self.backbone(x)
        x_reg = x_cls

        x_cls = self.cls_head(x_cls)
        x_reg = self.reg_head(x_reg)
        
        return (x_cls, x_reg)


class CnnModel(BaseModel):
    def __init__(self, num_classes=1, mode='cls'):
        super().__init__()
        self.conv1 = nn.Conv2d(1, 8, kernel_size=(1, 4), padding='valid')
        self.conv2 = nn.Conv2d(8, 8, kernel_size=(1, 5), padding='same', stride=(1,1))
        self.conv3 = nn.Conv2d(8, 16, kernel_size=(1, 4), padding='valid')
        self.conv4 = nn.Conv2d(16, 16, kernel_size=(1, 4), padding='same', stride=(1,1))
        self.conv5 = nn.Conv2d(16, 32, kernel_size=(1, 4), padding='valid')
        self.conv6 = nn.Conv2d(32, 32, kernel_size=(1, 4), stride=(1,1))
        self.fc1 = nn.Linear(448, 64)
        self.fc2 = nn.Linear(64, num_classes)
        self.bn1 = nn.BatchNorm1d(448)
        self.bn2 = nn.BatchNorm1d(64)
        self.conv1_bn = nn.BatchNorm2d(8)
        self.conv2_bn = nn.BatchNorm2d(8)
        self.conv3_bn = nn.BatchNorm2d(16)
        self.conv4_bn = nn.BatchNorm2d(16)
        self.conv5_bn = nn.BatchNorm2d(32)
        self.conv6_bn = nn.BatchNorm2d(32)
        self.mode = mode     

    def forward(self, x):
        x = F.relu(self.conv1(x))
        x = F.relu(self.conv2(x))
        x = F.max_pool2d(x, stride=(1,2),  kernel_size=(1,2))

        x = F.relu(self.conv3(x))
        x = F.relu(self.conv4(x))
        x = F.max_pool2d(x, stride=(1,2),  kernel_size=(1,2))

        
        x = F.relu(self.conv5(x))
        x = F.relu(self.conv6(x))
        x = F.max_pool2d(x, stride=(1,2),  kernel_size=(1,2))
        
        
        x = x.view(x.size(0), -1) # flatten

        x = self.bn1(x)
        x = F.relu(self.fc1(x))
        x = self.bn2(x)
        x = F.dropout(x, training=self.training) # replace with  batch norm

        if self.mode=="cls":
            x = F.sigmoid(self.fc2(x))
        else:
            x = F.relu(self.fc2(x))
        
        return x
    

class CnnModel1(BaseModel):
    def __init__(self, num_classes=1, mode='cls'):
        super().__init__()
        self.conv1 = nn.Conv2d(1, 4, kernel_size=(1, 4), padding='valid')
        self.conv2 = nn.Conv2d(4, 4, kernel_size=(1, 5), padding='same', stride=(1,1))
        self.conv3 = nn.Conv2d(4, 8, kernel_size=(1, 4), padding='valid')
        self.conv4 = nn.Conv2d(8, 8, kernel_size=(1, 4), padding='same', stride=(1,1))
        self.conv5 = nn.Conv2d(8, 16, kernel_size=(1, 4), padding='valid')
        self.conv6 = nn.Conv2d(16, 16, kernel_size=(1, 4), stride=(1,1))
        self.conv7 = nn.Conv2d(16, 32, kernel_size=(1, 4), padding='valid')
        self.conv8 = nn.Conv2d(32, 64, kernel_size=(1, 4), stride=(1,1))
        self.conv9 = nn.Conv2d(64, 128, kernel_size=(1, 4), padding='valid')
        self.conv10 = nn.Conv2d(128, 128, kernel_size=(1, 4), stride=(1,1))

        self.fc1 = nn.Linear(3328, 128)
        self.fc2 = nn.Linear(128, 64)
        self.fc3 = nn.Linear(64, num_classes)
        self.bn1 = nn.BatchNorm1d(3328)
        self.bn2 = nn.BatchNorm1d(128)
        self.bn3 = nn.BatchNorm1d(64)

        self.conv1_bn = nn.BatchNorm2d(8)
        self.conv2_bn = nn.BatchNorm2d(8)
        self.conv3_bn = nn.BatchNorm2d(16)
        self.conv4_bn = nn.BatchNorm2d(16)
        self.conv5_bn = nn.BatchNorm2d(32)
        self.conv6_bn = nn.BatchNorm2d(32)
        self.dropout = nn.Dropout(p=0.2)
        self.mode = mode     

    def forward(self, x):
        x = F.relu(self.conv1(x))
        x = F.relu(self.conv2(x))
        x = F.max_pool2d(x, stride=(1,2),  kernel_size=(1,2))

        x = F.relu(self.conv3(x))
        x = F.relu(self.conv4(x))
        x = F.max_pool2d(x, stride=(1,2),  kernel_size=(1,2))

        
        x = F.relu(self.conv5(x))
        x = F.relu(self.conv6(x))
        x = F.max_pool2d(x, stride=(1,2),  kernel_size=(1,2))

        x = F.relu(self.conv7(x))
        x = F.relu(self.conv8(x))
        x = F.max_pool2d(x, stride=(1,2),  kernel_size=(1,2))

        x = F.relu(self.conv9(x))
        x = F.relu(self.conv10(x))
        x = F.max_pool2d(x, stride=(1,2),  kernel_size=(1,2))

        
        x = x.view(x.size(0), -1) # flatten

        x = self.bn1(x)
        x = F.relu(self.fc1(x))
        x = self.bn2(x)
        x = self.dropout(x)

        x = F.relu(self.fc2(x))
        x = self.bn3(x)
        x = self.dropout(x) # replace with  batch norm

        if self.mode=="cls":
            x = F.sigmoid(self.fc2(x))
        else:
            x = self.fc3(x)
        
        return x

class baseline(BaseModel):
    def __init__(self, num_classes=1, mode='reg'):
        super().__init__()
        self.conv1 = nn.Conv2d(1, 10, kernel_size=(1, 4), padding='valid')
        self.conv2 = nn.Conv2d(10, 20, kernel_size=(1, 5), padding='same', stride=(1,1))
        self.conv3 = nn.Conv2d(20, 20, kernel_size=(1, 4), padding='valid')
        self.conv4 = nn.Conv2d(20, 40, kernel_size=(1, 4), padding='same', stride=(1,1))
        self.fc1 = nn.Linear(1400, 128)
        self.fc2 = nn.Linear(128, num_classes)
        self.flatten = nn.Flatten
        self.mode = mode        

    def forward(self, x):
        x = F.relu(self.conv1(x))
        x = F.relu(self.conv2(x))
        x = F.max_pool2d(x, stride=(1,2),  kernel_size=(1,2))

        x = F.relu(self.conv3(x))
        x = F.relu(self.conv4(x))
        x = F.max_pool2d(x, stride=(1,2),  kernel_size=(1,2))

        x = x.view(x.size(0), -1)

        x = F.relu(self.fc1(x))
        x = F.dropout(x, training=self.training) # replace with  batch norm
        if self.mode=="cls":
            x = F.sigmoid(self.fc2(x))
        else:
            x = self.fc2(x)
        
        return x

class ResidualBlock1d(nn.Module):
    def __init__(self, features_in, norm="in"):
        super().__init__()
        self.features_in = features_in
        self.block = nn.Sequential(
            nn.ReflectionPad1d(1),
            nn.Conv1d(self.features_in, self.features_in*2, 3),
            nn.BatchNorm1d(self.features_in*2),
            nn.ReLU(inplace=True),
            nn.ReflectionPad1d(1),
            nn.Conv1d(self.features_in*2, self.features_in*2, 3, stride=1),
            nn.BatchNorm1d(self.features_in*2),
            nn.ReLU(inplace=True)
        )
        self.downsample = nn.Sequential(
            nn.Conv1d(self.features_in, self.features_in*2, 1, stride=1),
            nn.BatchNorm1d(self.features_in*2),
            nn.ReLU(inplace=True)
        )

    def forward(self, x):
        return self.downsample(x) + self.block(x)
    
class ResidualCNN(BaseModel):
    def __init__(self, dim=4, n_residual=4, n_downsample=4, mode = None, num_classes=1):
        super().__init__()
        super(ResidualBlock1d).__init__()

        
        # Initialize input to 128 dim, (1, 152) -> (1, 128)
        layers = []
        layers += [nn.AdaptiveAvgPool1d(128)]

        # Initial convolution block, (1, 128) -> (4, 128)
        layers += [
            nn.ReflectionPad1d(2),  # (1, 134), 128+6
            nn.Conv1d(1, dim, 5),  # (4, 128), 134-7+1
            nn.BatchNorm1d(dim),
            nn.ReLU(inplace=True),
        ]

        # Downsampling with Residual blocks
        for _ in range(n_residual): # (4, 128) -> (8, 64) -> (16, 32) -> (32, 16) -> (64, 8)
            layers += [ResidualBlock1d(features_in=dim, norm="in")]
            dim *= 2
            layers += [
                nn.Conv1d(dim, dim, 3, stride=2, padding=1),  # (128-4+2)/2+1
                nn.BatchNorm1d(dim),
                nn.ReLU(inplace=True),
            ]
            

        """ for _ in range(n_downsample):  # (4, 128) -> (8, 64) -> (16, 32) -> (32, 16) -> (64, 8)
            layers += [
                nn.Conv1d(dim, dim * 2, 4, stride=2, padding=1),  # (128-4+2)/2+1
                nn.InstanceNorm1d(dim * 2),
                nn.ReLU(inplace=True),
            ]
            dim *= 2 """
        
        #layers += [nn.AdaptiveAvgPool1d(4)] # (64, 8) -> (64, 4)

        #layers += [nn.Conv1d(dim, int(dim/2), 1), # (64, 4) -> (32,2)
        #           nn.ReLU(inplace=True), 
        #           nn.AdaptiveAvgPool1d(2)]
           
        layers += [nn.Flatten()]
        # nn.Dropout(p=0.3, inplace=True)
        dim /= 2    
        layers += [ nn.BatchNorm1d(512), nn.Dropout(p=0.1, inplace=True), nn.Linear(512, num_classes)] # (64) -> (1)
        self.model = nn.Sequential(*layers)

    def forward(self, x):
        return self.model(x)  # (B, 1, 152) -> (B,1)

def resnet18( mode= "reg",
            num_classes= 1):
    model = models.resnet18(weights=models.ResNet18_Weights.DEFAULT)
    model.conv1 = nn.Conv2d(1, 64, kernel_size=7, stride=2, padding=3, bias=False)
    model.fc = nn.Linear(512 * 1, 1)
    return model

if __name__ == '__main__':

    
    model = ResidualCNN()
    
    model.eval()

    
    # B x C x H x W
    input = torch.rand(5, 1, 152)

    summary(model, input)
    print(model)

    out = model(input)
    print(out, out.size())

