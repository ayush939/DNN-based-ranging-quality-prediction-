# Import libraries
import pandas as pd
import numpy as np
from pathlib import Path
import matplotlib.pyplot as plt

file_paths = Path.home() / "/speech/dbwork/mul/spielwiese3/students/demittaa/dataset.pkl"
# Extract dataset
dataset = pd.read_pickle(str(file_paths))

print(dataset.columns)
# Select specific obstacle configurations
#ds = np.asarray(dataset.loc[dataset['Obstacles']=='0000000001'][['CIR','Error']])

# Select specific rooms
#ds = np.asarray(dataset.loc[(dataset['Room']==2)][['CIR','Error']])

# Select all samples
ds = np.asarray(dataset[['CIR','Error']])

# Get X,y for training  
print(ds[:,0].shape)

X = np.vstack(ds[:,0])
Y = np.array(ds[:,1])

print(X.shape)

error = Y
mean, std = np.mean(error), np.std(error)
fig, ax = plt.subplots()

bp = ax.boxplot(error, showmeans=True)
for i, line in enumerate(bp['medians']):
    x, y = line.get_xydata()[1]
    text = ' μ={:.2f}\n σ={:.2f}'.format(mean, std)
    ax.annotate(text, xy=(x, y))
fig.savefig('.boxplotlos-nlos.jpg')
