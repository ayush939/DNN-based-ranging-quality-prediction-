import torch
import torch.nn as nn
import torch.nn.functional as F

class HuberLoss(nn.Module):
    def __init__(self, delta=0.05):
        super(HuberLoss, self).__init__()
        self.delta = delta

    def forward(self, predictions, targets):
        error = predictions - targets
        loss = torch.abs(error)

        mask = loss <= self.delta
        loss = torch.where(mask, torch.zeros_like(loss), loss)

        #loss = loss[loss!=0.00]

        return torch.mean(loss)

def nll_loss(output, target):
    return F.nll_loss(output, target)

def cross_entropy(output, target):
    return F.cross_entropy(output, target)

def binary_cross_entropy(output, target):
    return F.binary_cross_entropy(output, target)

def mse_loss(output, target):
    return F.mse_loss(output, target)

def mae_loss(output, target):
    return F.l1_loss(output, target)

def huber_loss(output, target):
    huberL = HuberLoss(delta=0.03)
    return huberL(output, target)
