import os
import torch
import umap
import math
import random
import numpy as np
import pandas as pd
from pathlib import Path
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.cluster import KMeans
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA
from sklearn.utils.class_weight import compute_class_weight


def transform(cir):
    comp = torch.fft.fft(cir)
    mag = comp.abs()
    phase = comp.angle()
    
    # add noise
    #mag = torch.normal(0, 1, size=(152,)) + mag
    mag[140:150] =  0
   
    real = torch.mul(mag, torch.cos(phase))
    imag = torch.mul(mag, torch.sin(phase))

    
    cir = torch.fft.ifft(torch.view_as_complex(torch.stack((real, imag), dim=1)))
    cir = cir.real
    
    return cir

def fft_analysis(file_paths):

    input_arr = load_data_from_folder(file_paths)
    input_arr = input_arr.to_numpy()
    print(len(input_arr))
    # create blank output_arrays
    error_arr = np.zeros((len(input_arr), 1))
    cir_arr = np.zeros((len(input_arr), 152))
    label_arr = np.zeros((len(input_arr), 1))

    for i in range(len(input_arr)):
        fp_idx = int(input_arr[i][8])
        
        # calculate absolute ranging error
        error_arr[i] = math.fabs(math.sqrt(math.pow(input_arr[i][0] - input_arr[i][2], 2) +
                                            math.pow(input_arr[i][1] - input_arr[i][3], 2)) - input_arr[i][4])
         
        # labels
        label_arr[i, 0] = input_arr[i, 5]
        
        
        
        # pack cir to output cir array
        cir_arr[i] = input_arr[i][fp_idx -20 + 24: fp_idx -20 + 24 + 152] / input_arr[i][17]

    """
    fft_mag = []
    fft_phase = []
    for elem in cir_arr:
        complex_val = np.fft.fft(elem)
        
        fft_mag.append(np.abs(complex_val))
        fft_phase.append(np.angle(complex_val))


    #fft_phase = np.random.normal(1,0.2, (len(fft_mag), 152)) + fft_phase
    fft_mag = np.random.normal(3,6, (len(fft_mag), 152)) + fft_mag
    fft_mag[:,140:] = 0
    #print(fft_mag[0])

    ifft = []
    for elem in zip(fft_mag, fft_phase):
        real =np.multiply(elem[0], np.cos(elem[1]))
        imag = np.multiply(elem[0], np.sin(elem[1]))
        cir = np.real_if_close(np.fft.ifft(np.array([complex(a,b) for a,b in zip(real, imag)], dtype = 'complex_')))
        
        ifft.append(cir)
    

    cir_new = transform(torch.from_numpy(cir_arr[0]))
    plt.plot(range(0, 152), cir_new.numpy(), color="orange")
    plt.plot(range(0,152), cir_arr[0])

    
    fig1, axs1 = plt.subplots(nrows=5, ncols=1)
    
    for i in range(5):
        axs1[i].plot(range(0,len(cir_new)), cir_new, color="orange")
        axs1[i].plot(range(0,len(cir_arr[i])), cir_arr[i])
    fig1.savefig("ifft.jpg")
    """
    

    #kmeans = KMeans(n_clusters=2, random_state=0, n_init="auto").fit(fft_mag)
    #klabels = kmeans.labels_
    pca = PCA(3)
    reducer = umap.UMAP()
    #embedding = reducer.fit_transform(cir_arr)
    #print(embedding.shape)
    # reduce dimension to 2

    coords = pca.fit_transform(cir_arr)
    print(coords.shape)
    #plt.scatter(coords[:, 0], coords[:, 1], 20, c=klabels, cmap='spring')
    #plt.savefig("./figures/kmeans-jpg")
    fig = plt.figure()
    ax = fig.add_subplot(projection='3d')
    col=[]
    for elem in input_arr[:,-1]:
        #print(elem)
        if elem==2:
            col.append(0)
        else:
            col.append(1)
    ax.scatter(coords[:, 0], coords[:, 1], coords[:,2],  c=col, cmap='spring')
    fig.savefig("./figures/gt-jpg")
    
    

def load_data_from_folder(folderpath, val=[]):
    """
    Read all .csv files inside the dataset folder to pandas dataframe
    """
    rootdir = folderpath
    
    output_arr =pd.DataFrame()
    first = 1
    for dirpath, dirnames, filenames in os.walk(rootdir):
        for i, file in enumerate(filenames):
            if ".csv" in file : 
                filename = os.path.join(dirpath, file)
                print("Loading " + filename )
               
                # read data from file
                if 'NLOS' in str(filename):
                    df = pd.read_csv(filename,  header=0)
                else:
                    df = pd.read_csv(filename,  header=None)
                df = pd.concat([df, pd.DataFrame([i for x in range(0, len(df))])], axis=1)
                output_arr = pd.concat([output_arr, df])
    
                """
                input_data = df.to_numpy()
                # append to array
                if first > 0:
                    first = 0
                    output_arr = input_data
                else:
                    output_arr = np.vstack((output_arr, input_data))
                """
    return output_arr

def import_localization_data(val, mean, std, scale, split_type, split_ratio, cir_len=152 ):
    """
    Calculate ranging error and import CIR data

    Parameters
    ----------
    file_path : str
        absolute path to input .csv file

    Returns
    -------
    error_arr : numpy.array
        array of ranging errors from input data
    cir_arr : numpy.array
        array of CIR vectors from .csv file (length=152)
    """
    # import from file

    file_paths = Path.home() / "/speech/dbwork/mul/spielwiese3/students/demittaa/UWB-localization/localization"
    input_arr = load_data_from_folder(str(file_paths) + "/dataset1")
    
    train_len = len(input_arr)
    val_input_arr = load_data_from_folder(str(file_paths) + "/dataset2")
    
    input_arr = pd.concat([input_arr, val_input_arr], ignore_index=True)

    input_arr = input_arr.to_numpy()
    
    count = 0 
    for i in range(len(input_arr)):
         if input_arr[i, 5] == 0:
              count=count+1
    print("Total Dataset LOS :", count/len(input_arr))


    # randomize input array
    np.random.seed(5)

    if split_type == "random":
        np.random.shuffle(input_arr)
    

    # create blank output_arrays
    error_arr = np.zeros((len(input_arr), 1))
    dist = np.zeros((len(input_arr), 1))
    rang = np.zeros((len(input_arr), 1))
    cir_arr = np.zeros((len(input_arr), 1016), dtype=int)
    label_arr = np.zeros((len(input_arr), 1))

    for i in range(len(input_arr)):
        fp_idx = int(input_arr[i][8])
        
        # calculate absolute ranging error
        error_arr[i] = math.sqrt(math.pow(input_arr[i][0] - input_arr[i][2], 2) +
                                            math.pow(input_arr[i][1] - input_arr[i][3], 2)) - input_arr[i][4]
        
        # calculate  ranging error
        #error_arr[i] = math.sqrt(math.pow(input_arr[i][0] - input_arr[i][2], 2) +
        #                                    math.pow(input_arr[i][1] - input_arr[i][3], 2)) - input_arr[i][4]
        
        dist[i] = math.sqrt(math.pow(input_arr[i][0] - input_arr[i][2], 2) +
                                            math.pow(input_arr[i][1] - input_arr[i][3], 2))
        rang[i] = input_arr[i][4]
        
        # labels
        label_arr[i, 0] = input_arr[i, 5]
        
        # pack cir to output cir array
        #arr = input_arr[i][fp_idx -20 + 24: fp_idx -20 + 24 + cir_len] / input_arr[i][17]
        arr = input_arr[i][24:1040] / input_arr[i][17]
        arr = np.ceil(arr)
        arr = arr.astype(int)
        
        cir_arr[i] = arr

    max = np.max(cir_arr.flatten())
    min = np.min(cir_arr.flatten())
    cir_arr = (cir_arr-min)/(max-min)
    """
    count1=0
    count2=0
    for i in range(len(cir_arr)):
        
        if error_arr[i] == 0 and label_arr[i] == 1 and count1<5:
            plt.plot(range(0,len(cir_arr[i])), cir_arr[i])
            plt.savefig(f'los_outlier{count1}.jpg')
            plt.clf()
            count1+=1
        
    print('LOS >1 ', count1)
    print('NLOS ', count2)
    
    
    temp = label_arr[:,0]
    los = []
    nlos = []
    for i in range(len(temp)):
        if temp[i] == 0:
              los.append((rang[i], dist[i]))
        else:
             nlos.append((rang[i], dist[i]))
    fig,ax = plt.subplots() 

    #ax.hist(los,5, density=True, histtype='bar')

    ax.scatter([x[1] for x in los], [x[0] for x in los], label="los", marker='x')
    ax.plot([x[1] for x in los], [x[1] for x in los], color='orange')
    #ax.scatter([x[1] for x in nlos], [x[0] for x in nlos], label="nlos", marker='x')
    #ax.legend(loc='upper right', bbox_to_anchor=(1, 0.5))
    #ax.set_xlabel("LOS/NLOS data points")
    #ax.set_ylabel("range error")
    #fig.suptitle('Ranging error vs CIR class')
    plt.savefig("./figures/errorVSclass.jpg")
    """
    
    # train test split

    if split_type == "random":
       
        train_cir, test_cir, train_label, test_label = train_test_split(cir_arr, label_arr, test_size=split_ratio, 
                                                                        random_state=7, stratify=label_arr)
        train_cir1, test_cir, train_error, test_error = train_test_split(cir_arr, error_arr, test_size=split_ratio, 
                                                                         random_state=7,stratify=label_arr)
        np.testing.assert_array_equal(train_cir, train_cir1)
    else:
        train_cir, test_cir, train_label, test_label = cir_arr[0:train_len,:], cir_arr[train_len:,:], label_arr[0:train_len,:], label_arr[train_len:,:]
        train_error, test_error = error_arr[0:train_len,:], error_arr[train_len:,:]
    
    # check data imbalance 
    count = 0
    for elem in train_label:    
        if elem[0] == 0 :
            count+=1
    print("Train LOS ratio:", count/len(train_label))

    count = 0
    for elem in test_label:
        
        if elem[0] == 0 :
            count+=1
    print("Validation LOS ratio:", count/len(test_label))

    # normalization
    global_mean = mean
    global_std = std

    if val:
        if scale:
            test_cir = (test_cir - global_mean) / global_std
        return (test_label, test_error, test_cir, global_mean, global_mean)
        
    else: 
        if scale:

            global_mean = np.mean(np.mean(train_cir, axis=1))
            global_std = np.std(train_cir.flatten())

            train_cir = (train_cir - global_mean) / global_std

        return (train_label, train_error, train_cir, global_mean, global_std)
    

def import_classification_data(file_paths, mean, std, split_ratio = 0.2, cir_len=152, val=False, scale=False ): 
    """
    Calculate ranging error and import CIR data

    Parameters
    ----------
    file_path : str
        absolute path to input .csv file

    Returns
    -------
    error_arr : numpy.array
        array of ranging errors from input data
    cir_arr : numpy.array
        array of CIR vectors from .csv file (length=152)
    """
    # import from file
    input_arr = load_data_from_folder(file_paths)
    input_arr = input_arr.to_numpy()


    count = 0 
    for i in range(len(input_arr)):
            if input_arr[i, 0] == 0:
                count=count+1
    print("LOS ratio in total Dataset:", count/len(input_arr))


    # randomize input array
    np.random.seed(5)
    #np.random.shuffle(input_arr)
    
    # create blank output_arrays
    error_arr = np.zeros((len(input_arr), 1))
    cir_arr = np.zeros((len(input_arr), cir_len))
    label_arr = np.zeros((len(input_arr), 1))


    for i in range(len(input_arr)):
        fp_idx = int(input_arr[i][2])
        
        # labels
        label_arr[i, 0] = input_arr[i, 0]
        
        # pack cir to output cir array
        cir_arr[i] = input_arr[i][fp_idx -20 + 15 : fp_idx -20 + 15 + cir_len] / input_arr[i][9]


    # train test split
    train_cir, test_cir, train_label, test_label = train_test_split(cir_arr, label_arr, test_size=split_ratio, random_state=7, stratify=label_arr)

    

    # check data imbalance 
    
    count = 0
    for elem in train_label:   
            if elem == 0 :
                count+=1
    print("LOS ratio in train set:", count/len(train_label))

    count = 0
    for elem in test_label:   
            if elem == 0 :
                count+=1
    print("LOS ratio in val set:", count/len(test_label))

  
    # normalization
    global_mean = mean
    global_std = std

    if val:
        if scale:
            test_cir = (test_cir - global_mean) / global_std
        return (test_label, error_arr, test_cir, global_mean, global_mean)
        
    else: 
        if scale:

            global_mean = np.mean(np.mean(train_cir, axis=1))
            global_std = np.std(train_cir.flatten())

            train_cir = (train_cir - global_mean) / global_std
            # print(global_std)
            # print(global_mean)

        return (train_label, error_arr, train_cir, global_mean, global_std)


def convert_data(input_arr, cir_len=152):
     # create blank output_arrays
    error_arr = np.zeros((len(input_arr), 1))
    cir_arr = np.zeros((len(input_arr), cir_len))
    label_arr = np.zeros((len(input_arr)))

    for i in range(len(input_arr)):
        fp_idx = int(input_arr[i][2])
        
        # labels
        label_arr[i] = input_arr[i, 0]
        
        # pack cir to output cir array
        cir_arr[i] = input_arr[i][fp_idx -20 + 15: fp_idx -20 + 15 + cir_len] / input_arr[i][9]
    
    labels = np.zeros((len(label_arr), 2))
    labels[:,0] = label_arr
    for i in range(len(labels)):
        if labels[i,0] == 0:
            labels[i, 1] = 1
        else:
             labels[i,1] = 0

    return cir_arr, labels


def create_crossVal_classification_dataset(filepath, cir_len=152, val=[], scale=False):

    # extract raw train and val data according to the filename
    train_arr = pd.DataFrame()
    val_arr = pd.DataFrame()
    first = 1
    for dirpath, dirnames, filenames in os.walk(filepath):
        for file in filenames:
            if ".csv" in file and int(str(file).split('.csv')[0][-1]) not in val: 
               
                filename = os.path.join(dirpath, file)
                print("Loading " + filename )
                output_data = []
                # read data from file
                df = pd.read_csv(filename, sep=',', header=0)
                
                train_arr = pd.concat([train_arr, df])
            
            elif ".csv" in file and int(str(file).split('.csv')[0][-1]) in val:
                
                filename = os.path.join(dirpath, file)
                print("Loading " + filename )
                output_data = []
                # read data from file
                df = pd.read_csv(filename, sep=',', header=0)
                
                val_arr = pd.concat([val_arr, df])

    # convert to numpy array
    train_arr = train_arr.to_numpy()
    val_arr = val_arr.to_numpy()


    train_cir, train_labels = convert_data(train_arr, cir_len=cir_len)
    val_cir, val_labels = convert_data(val_arr, cir_len=cir_len)
    
    #global_mean = np.mean(np.mean(val_cir, axis=1))
    global_mean = np.mean(train_cir.flatten())
    global_std = np.std(train_cir.flatten())
    
    print(global_std)
    print(global_mean)
    print(train_cir[0])
    

    return train_cir, val_cir, train_labels, val_labels         
    

if __name__ == "__main__":

    dataPath =  Path.home() / "/speech/dbwork/mul/spielwiese3/students/demittaa/UWB-localization/localization"
    # view effect of cir normalization
    
    labels, error, cir, mean, td = import_localization_data(val=False, 
                                                            split_type="gen", 
                                                            split_ratio="0.2", 
                                                            scale=False, 
                                                            mean=0, 
                                                            std=1)
    #transform(a)
    #fft_analysis(str(dataPath) + "/dataset1")


    
    #labels, _, cir, mean, std = import_classification_data(str(dataPath), val=False, scale=False)
    #labels, _, cir = import_localization_data(dataPath, split_ratio = 0.4, cir_len=152, val=False)
    
    #print(labels.shape)


    #print("class weights", compute_class_weight('balanced', classes=np.unique(labels[:,0]), y=labels[:,0]))

    fig1, axs1 = plt.subplots(nrows=5, ncols=1)
    fig2, axs2 = plt.subplots(nrows=5, ncols=1)
    fig1.suptitle('los_NoScale')
    fig2.suptitle('nlos_NoScale')

    los = []
    nlos = []
    
    for i in range(len(labels)):
        if labels[i,0] == 0:
            los.append(cir[i]) 
        else:
            nlos.append(cir[i])

    for i in range(5):
         axs1[i].plot(range(0,152), los[i])
    
    for i in range(5):
         axs2[i].plot(range(0,152), nlos[i])

    fig1.savefig('./figures/reg_los_NoScale.jpg')
    fig2.savefig('./figures/reg_nlos_NoScale.jpg')
    """

    #for i in range(1,8):
    #create_crossVal_classification_dataset(dataPath, cir_len=152, val=[], scale=False)
         
    #import_classification_data(dataPath, split_ratio = 0.2, cir_len=152, val=False, scale=True)
    """