import os
import torch
import umap
import math
import random
import numpy as np
import pandas as pd
import seaborn as sns
from pathlib import Path
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.cluster import KMeans
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA
from sklearn.utils.class_weight import compute_class_weight
from sklearn.preprocessing import StandardScaler

def import_zenodo(data_mode):
    file_paths = Path.home() / "/speech/dbwork/mul/spielwiese3/students/demittaa/dataset.pkl"
    # Extract dataset
    dataset = pd.read_pickle(str(file_paths))

    print(dataset.columns)
   
    # Select  rooms 1 & 3 for train and room 2 for val
    ds_test = np.asarray(dataset.loc[(dataset['Room']==2)][['CIR','Error']])
    ds_train = np.asarray(dataset.loc[(dataset['Room']==1) | (dataset['Room']==3)][['CIR','Error']])

    # Get X,y for training  

    train_cir = np.vstack(ds_train[:,0]).astype(float)
    train_error = np.array(ds_train[:,1]).astype(float)
    test_cir = np.vstack(ds_test[:,0]).astype(float)
    test_error = np.array(ds_test[:,1]).astype(float)

    # normalize data
    scaler = StandardScaler()
    train_cir = scaler.fit_transform(train_cir)
    test_cir = scaler.transform(test_cir)

    # expand dims
    train_error = np.expand_dims(train_error, axis=1)
    test_error = np.expand_dims(test_error, axis=1)

    label = np.zeros(train_error.shape)

    if data_mode == 0:
        return (train_cir, label, train_error)
    elif data_mode == 1:
        return (test_cir, label, test_error)
    else:
        raise ValueError('wrong mode selected!')


def load_data_from_folder(folderpath):
    """
    Read all .csv files inside the dataset folder to pandas dataframe
    """
    rootdir = folderpath
    
    output_arr =pd.DataFrame()
    for dirpath, dirnames, filenames in os.walk(rootdir):
        for i, file in enumerate(filenames):
            if ".csv" in file : 
                filename = os.path.join(dirpath, file)
                print("Loading " + filename )
               
                
                df = pd.read_csv(filename,  header=0)
                #df = pd.concat([df, pd.DataFrame([i for x in range(0, len(df))])], axis=1)
                output_arr = pd.concat([output_arr, df])
    
    return output_arr


def import_local_data(data_mode, mean, std, scale, split_type, split_ratio, cir_len=152, pca = False):
    folderPath = Path.home() / "/speech/dbwork/mul/spielwiese3/students/demittaa/Local_dataset/NLOS"
    data = load_data_from_folder(str(folderPath))
    print(data.shape)

    # Data cleaning
    # -------------------------------------------------------------------------------------------------------------------------------
    # remove 0 CIR values
    mask = data.iloc[:, 1018].notnull() 
    data = data[mask]

    # remove extreme range values
    mask2 = data.iloc[:, 1019] < 50
    data = data[mask2]
    
    
    # remove the offset from ranging error 
    antenna_delay = 0.4668
    data.iloc[:, 1019] = data.iloc[:, 1019] - antenna_delay
    
    # remove big CIR amp. value
    mask3 = data.iloc[:, 0:1016].values <= 100
    data = data[mask3]

    
    print("After Data cleaning:", data.shape)
    
    # keep certain type of NLOS data
    mask =  (0.00 < data.iloc[:, 1019]) & (4.00 > data.iloc[:, 1019])
    data = data[mask]

    # Data preprocessing
    # -----------------------------------------------------------------------------------------------------------------------------------
    input_arr = data.to_numpy()

    # create blank output_arrays
    error_arr = np.zeros((len(input_arr), 1))
    cir_arr = np.zeros((len(input_arr), cir_len))
    label_arr = np.zeros((len(input_arr), 1))
    material_arr = np.zeros((len(input_arr), 1))
    max_cir = []
    min_cir = []

    for i in range(len(input_arr)):
        
        fp_idx = int(input_arr[i][1018])

        cir_cropped = input_arr[i][fp_idx -40: fp_idx -40 + cir_len] / np.mean(input_arr[i][ 0: fp_idx -30 ])
        
        # extract ranging error
        error_arr[i] = input_arr[i, 1019]
        
        # labels
        label_arr[i, 0] = input_arr[i, 1016]

        # material
        material_arr[i, 0] = int(input_arr[i, 1017])

        
        # pack cir to output cir array
        max_cir.append(np.max(cir_cropped))
        min_cir.append(np.min(cir_cropped))
        cir_arr[i] = cir_cropped
            

    plt.figure()
    plt.boxplot(max_cir)
    plt.savefig("./dist.jpg")

    max_cir = sorted(max_cir)

    cir_arr = (cir_arr-np.min(min_cir))/(max_cir[-1] - np.min(min_cir))
    scaler = StandardScaler()
    #cir_arr = scaler.fit_transform(cir_arr)
    
    if pca:
        p = PCA(3)
        coords = p.fit_transform(cir_arr)
        print(coords.shape)
        fig = plt.figure()
        ax = fig.add_subplot(projection='3d')
        col=[]
        for elem in material_arr:
            #print(elem)
            if elem==3:
                col.append(0)
            else:
                col.append(1)
        ax.scatter(coords[:, 0], coords[:, 1], coords[:,2],  c=col, cmap='spring')
        fig.savefig("./figures/pca-local.jpg")

    # Data split
    # ------------------------------------------------------------------------------------------------------------------------------------------------------
    if split_type == "random":

        arr = np.hstack((cir_arr, input_arr[:, 1016:] ))

        idx = [f'CIR{i}' for i in range(0, cir_len)]
        idx.append('label')
        idx.append('material')
        idx.append('fpx')
        idx.append('range')
        idx.append('tag_pos')
        idx.append('anchor_id')

        data = pd.DataFrame(arr, columns=idx)
        data = data.groupby(by=['label', 'tag_pos', 'anchor_id']).agg(lambda x: list(x)).reset_index()
        
        # split LOS abd NLOS bins
        data_los = data # just LOS data.iloc[0:72,:]
        data_nlos = data.iloc[72:,:]
        
        # shuffle bins
        data_los = data_los.sample(frac=1, random_state=7)
        data_nlos = data_nlos.sample(frac=1, random_state=1)

        # train and test split
        split = int((1-split_ratio)*len(data_los))
        data_train = data_los.iloc[0:split,:] 
        #data_train = pd.concat([data_train, data_nlos.iloc[0:split,:]]).reset_index(drop=True) # just LOS
        data_train = data_train.sample(frac=1, random_state=7)

        data_test = data_los.iloc[split:,:]
        #data_test = pd.concat([data_test, data_nlos.iloc[split:,:]]).reset_index(drop=True) # just LOS
        data_test = data_test.sample(frac=1, random_state=1)

        # test -> test and val
        data_val = data_test.iloc[0:int(len(data_test)/2), :]
        data_test = data_test.iloc[int(len(data_test)/2):, :]

        # unpack train and test data from group of 100 to 1
        train_cir, train_error, test_cir, test_error, val_cir, val_error = pd.DataFrame(), pd.DataFrame(), pd.DataFrame(), pd.DataFrame(), pd.DataFrame(), pd.DataFrame()
        train_label, test_label, val_label = pd.DataFrame(), pd.DataFrame(), pd.DataFrame()

        for _, elem in data_train.iterrows():
            train_cir = pd.concat([pd.DataFrame(dict(elem)).iloc[:, 3:3+cir_len], train_cir])  # just LOS 0:100
            train_error = pd.concat([pd.DataFrame(dict(elem)).iloc[:, -1:], train_error])      # just LOS
            train_label = pd.concat([pd.DataFrame(dict(elem)).iloc[:, 0:1], train_label])       # just LOS

        for _, elem in data_test.iterrows():
            test_cir = pd.concat([pd.DataFrame(dict(elem)).iloc[:, 3:3+cir_len], test_cir])  # just LOS
            test_error = pd.concat([pd.DataFrame(dict(elem)).iloc[:, -1:], test_error])      # just LOS
            test_label = pd.concat([pd.DataFrame(dict(elem)).iloc[:, 0:1], test_label])      # just LOS
 
        for _, elem in data_val.iterrows():
            val_cir = pd.concat([pd.DataFrame(dict(elem)).iloc[:, 3:3+cir_len], val_cir])    # just LOS
            val_error = pd.concat([pd.DataFrame(dict(elem)).iloc[:, -1:], val_error])        # just LOS
            val_label = pd.concat([pd.DataFrame(dict(elem)).iloc[:, 0:1], val_label])        # just LOS

        print(train_cir.shape, train_error.shape, test_cir.shape, test_error.shape, val_cir.shape, val_error.shape)
        #print(val_label)
    else:
        raise ValueError

    # normalization
    global_mean = mean
    global_std = std

    if data_mode == 0:
        return (train_cir.values, train_label.values, train_error.values)
        
    elif data_mode == 1: 
        return (val_cir.values, val_label.values, val_error.values)
    
    elif data_mode == 2:
        return (test_cir.values, test_label.values, test_error.values)
    else:
        raise ValueError


if __name__ == "__main__":

    folderPath = Path.home() / "/speech/dbwork/mul/spielwiese3/students/demittaa/Local_dataset/"

    cir, label, error = import_local_data(data_mode=0, mean=0, std=1, scale=False, split_type="random", split_ratio=0.3, cir_len=152, pca = False)

    # input data scaling visualization 
    """
    fig1, axs1 = plt.subplots(nrows=5, ncols=1)
    fig2, axs2 = plt.subplots(nrows=5, ncols=1)
    fig1.suptitle('los')
    fig2.suptitle('nlos')

    los = []
    nlos = []
    
    for i in range(len(labels)):
        if labels[i,0] == 0:
            los.append(cir[i]) 
        else:
            nlos.append(cir[i])

    for i in range(5):
         axs1[i].plot(range(0,152), los[i])
    
    for i in range(5):
         axs2[i].plot(range(0,152), nlos[i])

    fig1.savefig('./los_NoScale.jpg')
    fig2.savefig('./nlos_NoScale.jpg')

    boxplot of train, val and test data
    """
    
    # analyse train, val and test data
    
    mean, std = np.mean(error), np.std(error)
    fig, ax = plt.subplots()

    bp = ax.boxplot(error, showmeans=True)
    for i, line in enumerate(bp['medians']):
        x, y = line.get_xydata()[1]
        text = ' μ={:.2f}\n σ={:.2f}'.format(mean, std)
        ax.annotate(text, xy=(x, y))
    fig.savefig('./figures/boxplotlos-nlos.jpg')

    #a, cnts = np.unique(label, return_counts=True)
    # print(cnts[0]/cnts[1])
    
    
    # los vs nlos boxplot 
    """
    los = []
    nlos = []
    for elem in zip(label, error):
        if elem[0] == 0:
            los.append(elem[1][0])
        else:
            nlos.append(elem[1][0])
    
    mean, std = [], []
    mean.append(np.mean(los))
    mean.append(np.mean(nlos))
    std.append(np.std(los))
    std.append(np.std(nlos))
    
    fig, ax = plt.subplots()
    columns = [los, nlos]
    bp = ax.boxplot(columns, showmeans=True)
    for i, line in enumerate(bp['medians']):
        x, y = line.get_xydata()[1]
        text = ' μ={:.2f}\n σ={:.2f}'.format(mean[i], std[i])
        ax.annotate(text, xy=(x, y))
    fig.savefig('./figures/boxplotlos-nlos.jpg')
    """

    # boxplot of total local data
    """
    #-------------------------------------------------------------------------------------------------------------------------------------------------## 
    
    data = load_data_from_folder(str(folderPath))
    print(data.shape)

    # remove 0 CIR values
    mask = data.iloc[:, 1018].notnull() 
    data = data[mask]

    # remove extreme range values
    mask2 = data.iloc[:, 1019] < 50
    data = data[mask2]
    print(data.shape)


    # remove the offset from ranging error 
    antenna_delay = 0.4668
    data.iloc[:, 1019] = data.iloc[:, 1019] - antenna_delay

    mean, std = [], []

    cl_0 = data[data.iloc[:, 1016] == 0].iloc[:, 1019]
    mean.append(cl_0.mean(axis=0))
    std.append(cl_0.std(axis=0))
    cl_1 = data[(data.iloc[:, 1017] == 1) & (data.iloc[:, 1016] == 1)].iloc[:, 1019]
    mean.append(cl_1.mean(axis=0))
    std.append(cl_1.std(axis=0))
    cl_2 = data[(data.iloc[:, 1017] == 2) & (data.iloc[:, 1016] == 1)].iloc[:, 1019]
    mean.append(cl_2.mean(axis=0))
    std.append(cl_2.std(axis=0))
    cl_3 = data[(data.iloc[:, 1017] == 3) & (data.iloc[:, 1016] == 1)].iloc[:, 1019]
    mean.append(cl_3.mean(axis=0))
    std.append(cl_3.std(axis=0))


    cl_nlos = pd.concat([cl_1, cl_2, cl_3], ignore_index=True, axis=0)
    print(cl_0.shape, cl_1.shape, cl_2.shape, cl_3.shape, cl_nlos.shape)


    fig, ax = plt.subplots()
    columns = [cl_0, cl_1, cl_2, cl_3]
    bp = ax.boxplot(columns, showmeans=True)

    for i, line in enumerate(bp['medians']):
        x, y = line.get_xydata()[1]
        text = ' μ={:.2f}\n σ={:.2f}'.format(mean[i], std[i])
        ax.annotate(text, xy=(x, y))

    plt.xticks([1, 2, 3, 4], ["LOS sampled ", "NLOS-column", "NLOS-Absorber", "NLOS-Metallic"], rotation=10)
    fig.savefig('./figures/boxplotlos-nlos.jpg')
    #----------------------------------------------------------------------------------------------------------------------------------------------------#
    """