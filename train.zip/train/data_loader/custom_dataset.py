import sys
import torch
from pathlib import Path
from torch.utils.data import Dataset, DataLoader

sys.path.append('./data_loader/')
from data_utils import import_classification_data, create_crossVal_classification_dataset, import_localization_data
from data_local import import_local_data, import_zenodo

import cProfile
import pstats

class CustomCIRDataset(Dataset):
    def __init__(self, dataset, data, scale, split_type, split_ratio, mean=0, std=1):

        if dataset == "UWBcls":
            self.labels, self.error, self.cir, self.mean, self.std = import_classification_data( val=data, 
                                                                                                split_ratio=split_ratio, 
                                                                                                scale=scale, 
                                                                                                mean=mean, 
                                                                                                std=std)
        elif dataset == "UWBreg":
            self.labels, self.error, self.cir, self.mean, self.std = import_localization_data(val=data, 
                                                                                              split_type=split_type, 
                                                                                              split_ratio=split_ratio, 
                                                                                              scale=scale, 
                                                                                              mean=mean, 
                                                                                              std=std)
        elif dataset == "zenodo":
            self.cir, self.labels, self.error = import_zenodo(data)
        elif dataset == "local":
            self.cir, self.labels, self.error = import_local_data(data_mode=data, mean=0, std=1, scale=False, split_type="random", split_ratio=0.3, cir_len=152, pca = False)
        else:
            raise ValueError("Dataset name not mentioned correctly in the config file")

    def __len__(self):
        return len(self.cir)
    

    def __getitem__(self, idx):
        
        
        cir = self.cir[idx]
        label = self.labels[idx]
        error = self.error[idx]

        return torch.as_tensor(cir), torch.as_tensor(label) , torch.as_tensor(error)

class CustomCrossVal(Dataset):

    def __init__(self, data_dir, val, validation_mode=False, scale=False):

        if validation_mode:
            _, self.cir, _, self.labels = create_crossVal_classification_dataset(data_dir, cir_len=152, val=val, scale=False)
        else:

            self.cir, _, self.labels, _ = create_crossVal_classification_dataset(data_dir, cir_len=152, val=val, scale=False)
       
    def __len__(self):
        return len(self.cir)

    def __getitem__(self, idx):
        
        
        cir = self.cir[idx]
        label = self.labels[idx]

        return torch.as_tensor(cir), torch.as_tensor(label)    

if __name__ == "__main__":
    with cProfile.Profile() as profile:
        dataPath =  Path.home() / "/speech/dbwork/mul/spielwiese3/students/demittaa/UWB-localization/localization"
        train_dataset = CustomCIRDataset(data_dir=str(dataPath), val=False)
        val_dataset = CustomCIRDataset(data_dir=str(dataPath), val=True)

        # print(next(iter(train_dataset)))
        # print(next(iter(val_dataset)))

        """
        results = pstats.Stats(profile)
        results.sort_stats(pstats.SortKey.TIME)
        results.print_stats()
        """
        # print(len(train_dataset), len(val_dataset))
        train_dataloader = DataLoader(train_dataset, batch_size=4, shuffle=True)
        data, label = next(iter(train_dataloader))

        print(label.size())
