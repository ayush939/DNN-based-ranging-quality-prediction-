import numpy as np
import torch
from torchvision.utils import make_grid
from base import BaseTrainer
import matplotlib.pyplot as plt
from torchmetrics import ConfusionMatrix
from utils import inf_loop, MetricTracker
from torchvision import transforms
from data_loader.data_utils import transform


def plot_input(data, data_aug, idx, target):
    fig1, axs1 = plt.subplots(nrows=5, ncols=1)

    col = ['blue', "green"]
    for i in range(0,5):
        axs1[i].plot(range(0, len(data[i,:].numpy())), data[i,:].numpy(), color=col[int(target.numpy()[i,0])])
        axs1[i].plot(range(0, len(data_aug[i,:].numpy())), data_aug[i,:].numpy(), color="orange")
    fig1.savefig(f"batch{idx}.jpg")

class Trainer(BaseTrainer):
    """
    Trainer class
    """
    def __init__(self, model, criterion, metric_ftns, optimizer, config, device,
                 data_loader, valid_data_loader=None, lr_scheduler=None, len_epoch=None):
        super().__init__(model, criterion, metric_ftns, optimizer, config)
        self.config = config
        self.device = device

        if self.config["mode"] == "cls":
            self.criterion = criterion[0]
        elif self.config["mode"] == "reg":
            self.criterion = criterion[1]
        self.data_loader = data_loader
        if len_epoch is None:
            # epoch-based training
            self.len_epoch = len(self.data_loader)
        else:
            # iteration-based training
            self.data_loader = inf_loop(data_loader)
            self.len_epoch = len_epoch
        self.valid_data_loader = valid_data_loader
        self.do_validation = self.valid_data_loader is not None
        self.lr_scheduler = lr_scheduler
        self.log_step = int(np.sqrt(data_loader.batch_size))

        self.train_metrics = MetricTracker('loss', *[m.__name__ for m in self.metric_ftns], writer=self.writer)
        self.valid_metrics = MetricTracker('loss', *[m.__name__ for m in self.metric_ftns], writer=self.writer)

    def _train_epoch(self, epoch):
        """
        Training logic for an epoch

        :param epoch: Integer, current training epoch.
        :return: A log that contains average loss and metric in this epoch.
        """
    
        self.model.train()
        
        self.train_metrics.reset()
        for batch_idx, (data, target, error) in enumerate(self.data_loader):
            
            #data_aug = transforms.Lambda(lambda x: torch.stack([transform(x_) for x_ in data]))(data)

            #plot_input(data=data, data_aug=data_aug, idx=batch_idx, target=target)
            #ydata = data_aug
            

            data = torch.unsqueeze(data, dim=1)
            #data = torch.unsqueeze(data, dim=1)

            data, target, error = data.to(self.device), target.to(self.device), error.to(self.device)

            self.optimizer.zero_grad()
            
            output = self.model(data.float())
            
          

            if self.config["mode"] == "reg":
                loss = self.criterion(output.float(), error.float())
                for met in self.metric_ftns:
                    self.train_metrics.update(met.__name__, met(output, error))
            elif self.config["mode"] == "cls":
                loss = self.criterion(output.float(), target.float())
                for met in self.metric_ftns:
                    self.train_metrics.update(met.__name__, met(output, target))

            loss.backward()
            self.optimizer.step()

            #self.writer.set_step((epoch - 1) * self.len_epoch + batch_idx)
            self.writer.set_step(epoch)
            self.train_metrics.update('loss', loss.item())
            

            if batch_idx % self.log_step == 0:
                self.logger.debug('Train Epoch: {} {} Loss: {:.6f}'.format(
                    epoch,
                    self._progress(batch_idx),
                    loss.item()))
                """
                fig, axs = plt.subplots(nrows=3, ncols=1)
                inp = torch.squeeze(data.cpu())
                axs[0].plot(range(0,152), inp[0])
                axs[0].set_ylabel(target.cpu()[0])
                axs[1].plot(range(0,152), inp[1])
                axs[1].set_ylabel(target.cpu()[1])
                axs[2].plot(range(0,152), inp[2])
                axs[2].set_ylabel(target.cpu()[2])
                
                self.writer.add_figure('input', data=fig)
                #self.writer.add_image('input', make_grid(data.cpu(), nrow=8, normalize=True))
                """
            if batch_idx == self.len_epoch:
                break
            # break
            
        log = self.train_metrics.result()

        if self.do_validation:
            val_log = self._valid_epoch(epoch)
            log.update(**{'val_'+k : v for k, v in val_log.items()})
            log.update({'lr': self.lr_scheduler.get_last_lr()})
        

        if self.lr_scheduler is not None:
            self.lr_scheduler.step()
        return log

    def _valid_epoch(self, epoch):
        """ 
        Validate after training an epoch

        :param epoch: Integer, current training epoch.
        :return: A log that contains information about validation
        """
        self.model.eval()
        self.valid_metrics.reset()
        confmat = ConfusionMatrix(task="binary").to(torch.device("cuda", 0))
        confmat.reset()
        
        with torch.no_grad():
            for batch_idx, (data, target, error) in enumerate(self.valid_data_loader):
                
                #print(data.shape, error.shape)
                #data = transforms.Lambda(lambda x: torch.stack([transform(x_) for x_ in data]))(data)
                data = torch.unsqueeze(data, dim=1)
                #data = torch.unsqueeze(data, dim=1)

                data, target, error = data.to(self.device), target.to(self.device), error.to(self.device)
                
                output = self.model(data.float())

                if self.config["mode"] == "reg":
                    loss = self.criterion(output.float(), error.float())
                    for met in self.metric_ftns:
                        self.valid_metrics.update(met.__name__, met(output, error))
                elif self.config["mode"] == "cls":
                    loss = self.criterion(output.float(), target.float())
                    for met in self.metric_ftns:
                        self.valid_metrics.update(met.__name__, met(output, target))
                
                # self.writer.set_step((epoch - 1) * len(self.valid_data_loader) + batch_idx, 'valid')
                self.writer.set_step(epoch , 'valid')
                self.valid_metrics.update('loss', loss.item())

                if self.config["mode"] == "cls":
                    confmat.update(output[:,0], target[:,0])

                #for met in self.metric_ftns:
                #    self.valid_metrics.update(met.__name__, met(output, target))
                                
                #self.writer.add_image('input', make_grid(data.cpu(), nrow=8, normalize=True))
        
        if self.config["mode"] == "cls":          
            fig_, ax_ = confmat.plot()
            self.writer.add_figure('conf-mat', data=fig_)
        

        # add histogram of model parameters to the tensorboard
        #for name, p in self.model.named_parameters():
        #    self.writer.add_histogram(name, p, bins='auto')
        return self.valid_metrics.result()

    def _progress(self, batch_idx):
        base = '[{}/{} ({:.0f}%)]'
        if hasattr(self.data_loader, 'n_samples'):
            current = batch_idx * self.data_loader.batch_size
            total = self.data_loader.n_samples
        else:
            current = batch_idx
            total = self.len_epoch
        return base.format(current, total, 100.0 * current / total)
    



class Trainer_multitask(BaseTrainer):
    """
    Trainer class
    """
    def __init__(self, model, criterion, metric_ftns, optimizer, config, device,
                 data_loader, valid_data_loader=None, lr_scheduler=None, len_epoch=None):
        super().__init__(model, criterion, metric_ftns, optimizer, config)
        self.config = config
        self.device = device

        assert len(criterion) == 2
        self.criterion_cls = criterion[0]
        self.criterion_reg = criterion[1]
        self.data_loader = data_loader
        if len_epoch is None:
            # epoch-based training
            self.len_epoch = len(self.data_loader)
        else:
            # iteration-based training
            self.data_loader = inf_loop(data_loader)
            self.len_epoch = len_epoch
        self.valid_data_loader = valid_data_loader
        self.do_validation = self.valid_data_loader is not None
        self.lr_scheduler = lr_scheduler
        self.log_step = int(np.sqrt(data_loader.batch_size))

        self.train_metrics = MetricTracker('loss', 'cls_loss', 'reg_loss', *[m.__name__ for m in self.metric_ftns], writer=self.writer)
        self.valid_metrics = MetricTracker('loss', 'cls_loss', 'reg_loss', *[m.__name__ for m in self.metric_ftns], writer=self.writer)

    def _train_epoch(self, epoch):
        """
        Training logic for an epoch

        :param epoch: Integer, current training epoch.
        :return: A log that contains average loss and metric in this epoch.
        """
        self.model.train()
        m = torch.nn.Softmax(dim=1)
        self.train_metrics.reset()
        for batch_idx, (data, target, error) in enumerate(self.data_loader):
            
            #data_aug = transforms.Lambda(lambda x: torch.stack([transform(x_) for x_ in data]))(data)

            #plot_input(data=data, data_aug=data_aug, idx=batch_idx, target=target)
            #ydata = data_aug

            data = torch.unsqueeze(data, dim=1)
            data = torch.unsqueeze(data, dim=1)

            data, target, error = data.to(self.device), target.to(self.device), error.to(self.device)

            self.optimizer.zero_grad()
            
            output = self.model(data.float())
            
            #print(target, m(output))

            loss_cls = self.criterion_cls(output[0].float(), target.float())
            loss_reg = self.criterion_reg(output[1].float(), error.float())

            loss = loss_cls #+ loss_reg

            loss.backward()
            self.optimizer.step()

            self.writer.set_step((epoch - 1) * self.len_epoch + batch_idx)
            self.train_metrics.update('loss', loss.item())
            self.train_metrics.update('cls_loss', loss_cls.item())
            self.train_metrics.update('reg_loss', loss_reg.item())
            #for met in self.metric_ftns:
            #    self.train_metrics.update(met.__name__, met(output, target))

            if batch_idx % self.log_step == 0:
                self.logger.debug('Train Epoch: {} {} Total Loss: {:.6f} Cls Loss: {:.6f} Reg Loss: {:.6f}'.format(
                    epoch,
                    self._progress(batch_idx),
                    loss.item(),
                    loss_cls.item(),
                    loss_reg.item()))
                """
                fig, axs = plt.subplots(nrows=3, ncols=1)
                inp = torch.squeeze(data.cpu())
                axs[0].plot(range(0,152), inp[0])
                axs[0].set_ylabel(target.cpu()[0])
                axs[1].plot(range(0,152), inp[1])
                axs[1].set_ylabel(target.cpu()[1])
                axs[2].plot(range(0,152), inp[2])
                axs[2].set_ylabel(target.cpu()[2])
                
                self.writer.add_figure('input', data=fig)
                #self.writer.add_image('input', make_grid(data.cpu(), nrow=8, normalize=True))
                """
            if batch_idx == self.len_epoch:
                break
            # break
            
        log = self.train_metrics.result()

        if self.do_validation:
            val_log = self._valid_epoch(epoch)
            log.update(**{'val_'+k : v for k, v in val_log.items()})

        if self.lr_scheduler is not None:
            self.lr_scheduler.step()
        return log

    def _valid_epoch(self, epoch):
        """ 
        Validate after training an epoch

        :param epoch: Integer, current training epoch.
        :return: A log that contains information about validation
        """
        self.model.eval()
        self.valid_metrics.reset()
        confmat = ConfusionMatrix(task="binary").to(torch.device("cuda", 0))
        confmat.reset()
        
        with torch.no_grad():
            for batch_idx, (data, target, error) in enumerate(self.valid_data_loader):

                #data = transforms.Lambda(lambda x: torch.stack([transform(x_) for x_ in data]))(data)
                data = torch.unsqueeze(data, dim=1)
                data = torch.unsqueeze(data, dim=1)

                data, target, error = data.to(self.device), target.to(self.device), error.to(self.device)
                
                output = self.model(data.float())

                loss_cls = self.criterion_cls(output[0].float(), target.float())
                loss_reg = self.criterion_reg(output[1].float(), error.float())

                loss = loss_cls + loss_reg

                self.writer.set_step((epoch - 1) * len(self.valid_data_loader) + batch_idx, 'valid')
                self.valid_metrics.update('loss', loss.item())
                self.valid_metrics.update('cls_loss', loss_cls.item())
                self.valid_metrics.update('reg_loss', loss_reg.item())

                
                #if self.config["mode"] == "cls":
                #    confmat.update(output[:,0], target[:,0])

                #for met in self.metric_ftns:
                #    self.valid_metrics.update(met.__name__, met(output, target))
                                
                #self.writer.add_image('input', make_grid(data.cpu(), nrow=8, normalize=True))
        
        #if self.config["mode"] == "cls":          
        #    fig_, ax_ = confmat.plot()
        #    self.writer.add_figure('conf-mat', data=fig_)
        

        # add histogram of model parameters to the tensorboard
        for name, p in self.model.named_parameters():
            self.writer.add_histogram(name, p, bins='auto')
        return self.valid_metrics.result()

    def _progress(self, batch_idx):
        base = '[{}/{} ({:.0f}%)]'
        if hasattr(self.data_loader, 'n_samples'):
            current = batch_idx * self.data_loader.batch_size
            total = self.data_loader.n_samples
        else:
            current = batch_idx
            total = self.len_epoch
        return base.format(current, total, 100.0 * current / total)
